/* bubbleChart creation function. Returns a function that will
 * instantiate a new bubble chart given a DOM element to display
 * it in and a dataset to visualize.
 *
 * Organization and style inspired by:
 * https://bost.ocks.org/mike/chart/
 *
 */
// Green Label Bubble for Bio Percentage


function bubbleChart() {
    // Constants for sizing
    var width = 1140;
    var height = 600;

    var test = null;

    
    // tooltip for mouseover functionality
    var tooltip = floatingTooltip('bubbles_tooltip', 240);

    // Locations to move bubbles towards, depending
    // on which view mode is selected.
    var center = { x: width / 2, y: height / 2 };


    //Prozentangabe BIO unter den Bubbles//Prozentangabe BIO unter den Bubbles
    //Prozentangabe BIO unter den Bubbles//Prozentangabe BIO unter den Bubbles    

    var percentage = {};
    var nodesX = null;

    //Untergruppe Sprachgebiet//Untergruppe Sprachgebiet//Untergruppe Sprachgebiet
    //Untergruppe Sprachgebiet//Untergruppe Sprachgebiet//Untergruppe Sprachgebiet

    var languageAreaCenters = {
        Deutschschweiz: { x: 1140/3 , y: height / 2 },
        Westschweiz: { x: 1140/3*2, y: height / 2 },

    };
    var languageAreaTitleX = {
        Deutschschweiz: 1140/3 - 27,
        Westschweiz: 1140/3*2 + 20,
    };
    
    var languageAreaPercentageX = {
        Deutschschweiz: 1140/3+20,
        Westschweiz: 1140/3*2+60,
    };

    //Untergruppe Region//Untergruppe Region//Untergruppe Region
    //Untergruppe Region//Untergruppe Region//Untergruppe Region 

    var regionCenters = {
        Städtisch: { x: 1140/4, y: height / 2 },
        Ländlich: { x: 1140/4*2, y: height / 2 },
        Intermediär: { x: 1140/4*3, y: height / 2 }
    };

    var regionTitleX = {
        Städtisch: 1140/4 - 50,
        Ländlich: 1140/4*2,
        Intermediär: 1140/4*3 + 40,
    };
    
    var regionPercentageX = {
        Städtisch: 1140/4-10,
        Ländlich: 1140/4*2+40,
        Intermediär: 1140/4*3+80,
    };
    
    

    //Untergruppe Einkaufsort//Untergruppe Einkaufsort//Untergruppe Einkaufsort
    //Untergruppe Einkaufsort//Untergruppe Einkaufsort//Untergruppe Einkaufsort 

    var placePurchaseCenters = {
        'Total Ausgaben Schweiz': { x: 1140/3, y: height / 2 },
        'Total Ausgaben Ausland': { x: 1140/3*2, y: height / 2 },
    };

    var placePurchaseTitleX = {
        'Total Ausgaben Schweiz': 1140/3-30,
        'Total Ausgaben Ausland': 1140/3*2+20,
    };
    
    var placePurchasePercentageX = {
        'Total Ausgaben Schweiz': 1140/3,
        'Total Ausgaben Ausland': 1140/3*2+70,
    };

    //Untergruppe Einkommen//Untergruppe Einkommen//Untergruppe Einkommen
    //Untergruppe Einkommen//Untergruppe Einkommen//Untergruppe Einkommen 

    var incomeCenters = {
        'bis 35000 CHF': { x: 1000/7+70, y: height / 2 },
        '35001 bis 50000 CHF': { x: 1000/7*2+70, y: height / 2 },
        '50001 bis 70000 CHF': { x: 1000/7*3+70, y: height / 2 },
        '70001 bis 90000 CHF': { x: 1000/7*4+70, y: height / 2 },
        '90001 bis 110000 CHF': { x: 1000/7*5+70, y: height / 2 },
        '> 110000 CHF': { x: 1000/7*6+70, y: height / 2 }, 
    };

    var incomeTitleX = {
        'bis 35000 CHF': { x: 1140/7-60, y: height / 2 },
        '35001 bis 50000 CHF': { x: 1140/7*2-20, y: height / 2 },
        '50001 bis 70000 CHF': { x: 1140/7*3, y: height / 2 },
        '70001 bis 90000 CHF': { x: 1140/7*4+10, y: height / 2 },
        '90001 bis 110000 CHF': { x: 1140/7*5+20, y: height / 2 },
        '> 110000 CHF': { x: 1140/7*6+40, y: height / 2 },
    };
    
    var incomePercentageX = {
        'bis 35000 CHF': { x: 1140/7-40, y: height / 2 },
        '35001 bis 50000 CHF': { x: 1140/7*2-10, y: height / 2 },
        '50001 bis 70000 CHF': { x: 1140/7*3+10, y: height / 2 },
        '70001 bis 90000 CHF': { x: 1140/7*4+30, y: height / 2 },
        '90001 bis 110000 CHF': { x: 1140/7*5+50, y: height / 2 },
        '> 110000 CHF': { x: 1140/7*6+80, y: height / 2 },
    };

    //Untergruppe Alter Referenzperson//Untergruppe Alter Referenzperson//Untergruppe Alter Referenzperson
    //Untergruppe Alter Referenzperson//Untergruppe Alter Referenzperson//Untergruppe Alter Referenzperson 

    var ageRpCenters = {
        'bis 34 Jahre': { x: 1140/5, y: height / 2 },
        '35-49 Jahren': { x: 1140/5*2, y: height / 2 },
        '50-64 Jahren': { x: 1140/5*3, y: height / 2 },
        '65 Jahren und älter': { x: 1140/5*4, y: height / 2 },
    };

    var ageRpTitleX = {
        'bis 34 Jahre': { x: 1140/5-70, y: height / 2 },
        '35-49 Jahren': { x: 1140/5*2-20, y: height / 2 },
        '50-64 Jahren': { x: 1140/5*3+20, y: height / 2 },
        '65 Jahren und älter': { x: 1140/5*4+50, y: height / 2 },
    };
    
    var ageRpPercentageX = {
        'bis 34 Jahre': { x: 1140/5-20, y: height / 2 },
        '35-49 Jahren': { x: 1140/5*2+10, y: height / 2 },
        '50-64 Jahren': { x: 1140/5*3+50, y: height / 2 },
        '65 Jahren und älter': { x: 1140/5*4+100, y: height / 2 },
    };

    //Untergruppe Haushaltsgrösse//Untergruppe Haushaltsgrösse//Untergruppe Haushaltsgrösse
    //Untergruppe Haushaltsgrösse//Untergruppe Haushaltsgrösse//Untergruppe Haushaltsgrösse 

    var hhSizeCenters = {
        '1 Person': { x: 1140/5+30, y: height / 2 },
        '2 Personen': { x: 1140/5*2, y: height / 2 },
        '3 & 4 Personen': { x: 1140/5*3, y: height / 2 },
        '5+ Personen': { x: 1140/5*4-30, y: height / 2 },
    };

    var hhSizeTitleX = {
        '1 Person': { x: 1140/5-40, y: height / 2 },
        '2 Personen': { x: 1140/5*2-30, y: height / 2 },
        '3 & 4 Personen': { x: 1140/5*3+10, y: height / 2 },
        '5+ Personen': { x: 1140/5*4+20, y: height / 2 },
    };
    
    var hhSizePercentageX = {
        '1 Person': { x: 1140/5-10, y: height / 2 },
        '2 Personen': { x: 1140/5*2+10, y: height / 2 },
        '3 & 4 Personen': { x: 1140/5*3+40, y: height / 2 },
        '5+ Personen': { x: 1140/5*4+70, y: height / 2 },
    };

    //Untergruppe Anzahl Kinder//Untergruppe Anzahl Kinder//Untergruppe Anzahl Kinder
    //Untergruppe Anzahl Kinder//Untergruppe Anzahl Kinder//Untergruppe Anzahl Kinder 

    var nrKidsCenters = {
        'keine Kinder': { x: 1140/5+30, y: height / 2 },
        '1 Kind': { x: 1140/5*2, y: height / 2 },
        '2 Kinder': { x: 1140/5*3, y: height / 2 },
        '3 Kinder und mehr': { x: 1140/5*4-30, y: height / 2 },
    };

    var nrKidsTitleX = {
        'keine Kinder': { x: 1140/5-30, y: height / 2 },
        '1 Kind': { x: 1140/5*2-20, y: height / 2 },
        '2 Kinder': { x: 1140/5*3+10, y: height / 2 },
        '3 Kinder und mehr': { x: 1140/5*4+30, y: height / 2 },
    };
    
    var nrKidsPercentageX = {
        'keine Kinder': { x: 1140/5-10, y: height / 2 },
        '1 Kind': { x: 1140/5*2+20, y: height / 2 },
        '2 Kinder': { x: 1140/5*3+50, y: height / 2 },
        '3 Kinder und mehr': { x: 1140/5*4+70, y: height / 2 },
    };






    // @v4 strength to apply to the position forces
    var forceStrength = 0.04;

    // These will be set in create_nodes and create_vis
    var svg = null;
    var bubbles = null;
    var nodes = [];

    // Charge function that is called for each node.
    // As part of the ManyBody force.
    // This is what creates the repulsion between nodes.
    //
    // Charge is proportional to the diameter of the
    // circle (which is stored in the radius attribute
    // of the circle's associated data.
    //
    // This is done to allow for accurate collision
    // detection with nodes of different sizes.
    //
    // Charge is negative because we want nodes to repel.
    // @v4 Before the charge was a stand-alone attribute
    //  of the force layout. Now we can use it as a separate force!
    function charge(d) {
        return -Math.pow(d.radius, 2.0) * forceStrength;
    }

    // Here we create a force layout and
    // @v4 We create a force simulation now and
    //  add forces to it.
    var simulation = d3.forceSimulation()
    .velocityDecay(0.15)
    .force('x', d3.forceX().strength(forceStrength).x(center.x))
    .force('y', d3.forceY().strength(forceStrength).y(center.y))
    .force('charge', d3.forceManyBody().strength(charge))
    .on('tick', ticked);

    // @v4 Force starts up automatically,
    //  which we don't want as there aren't any nodes yet.
    simulation.stop();






    /* Hier werden die Nodes generiert.
   * This data manipulation function takes the raw data from
   * the CSV file and converts it into an array of node objects.
   * Each node will store data and visualization values to visualize
   * a bubble.
   *
   * rawData is expected to be an array of data objects, read in from
   * one of d3's loading functions like d3.csv.
   *
   * This function returns the new node array, with a node in that
   * array for each element in the rawData input.
   */
    function createNodes(rawData) {
        // Use the max total_amount in the data as the max in the scale's domain
        // note we have to ensure the total_amount is a number.
        var maxAmount = d3.max(rawData, function (d) {return d['Menge je Haushalt']; });

        // Sizes bubbles based on area.
        // @v4: new flattened scale names.
        var radiusScale = d3.scalePow()
        .exponent(0.5)
        .range([2, 100])
        .domain([0, maxAmount]);




        // Mapping der Daten aus dem CSV.  
        // Use map() to convert raw data into node data.
        // Checkout http://learnjsdata.com/ for more on
        // working with data.
        var myNodes = [];
        rawData.forEach(function(d) {
            var arr = [];
            for (let i = 0; i < Math.round(+d.Prozent); i++) {
                arr.push(
                    {
                        parent_id: d.ID,
                        id: i,
                        radius: 10,
                        bereich: d['Bereich'],
                        group: d['BIO/N BIO'],
                        filter: d['Vergleichssegment-Gruppen'],
                        subFilter: d.Haushaltstyp,
                        year: d.Jahr,
                        unit: d['Mengeneinheit'],
                        amount: d['Menge je Haushalt'],
                        totalAmount: d['Totalmenge je Haushalt'],
                        value: d['Wert je Haushalt'],
                        totalValue: d['Totalwert je Haushalt'],
                        percent: d.Prozent,
                        percentOfValue: d.Prozent_Wert,
                        
                        
                        x: Math.random() * 900,
                        y: Math.random() * 800
                    }
                );
            }
            myNodes = myNodes.concat(arr);
        });

        // sort them to prevent occlusion of smaller nodes.
        myNodes.sort(function (a, b) { return b.value - a.value; });

        return myNodes;
    }






    /* Hier werden die Bubbles erstellt.
   * Main entry point to the bubble chart. This function is returned
   * by the parent closure. It prepares the rawData for visualization
   * and adds an svg element to the provided selector and starts the
   * visualization creation process.
   *
   * selector is expected to be a DOM element or CSS selector that
   * points to the parent element of the bubble chart. Inside this
   * element, the code will add the SVG continer for the visualization.
   *
   * rawData is expected to be an array of data objects as provided by
   * a d3 loading function like d3.csv.
   */
    var chart = function chart(selector, rawData) {
        // convert raw data into nodes data
        test = rawData;
        nodes = createNodes(rawData);

        // Create a SVG element inside the provided selector
        // with desired size.
        svg = d3.select(selector)
            .append('svg')
            .attr('width', width)
            .attr('id', 'mysvg')
            .attr('height', height);

        // Bind nodes data to what will become DOM elements to represent them.
        bubbles = svg.selectAll('.bubble')
            .data(nodes, function (d) { return d.parent_id + d.id; });

        // Create new circle elements each with class `bubble`.
        // There will be one circle.bubble for each object in the nodes array.
        // Initially, their radius (r attribute) will be 0.
        // @v4 Selections are immutable, so lets capture the
        //  enter selection to apply our transtition to below.
        var bubblesE = bubbles.enter().append('circle')
        .classed('bubble', true)
        .attr('r', 0)
        .attr('fill', function (d) { 
            return fillColor(d.group);
        })
        .attr('stroke', function (d) { return d3.rgb(fillColor(d.group)).darker(); })
        .attr('stroke-width', 2)
        .on('mouseover', showDetail)
        .on('mouseout', hideDetail);

        // @v4 Merge the original empty selection and the enter selection
        bubbles = bubbles.merge(bubblesE);

        // Fancy transition to make bubbles appear, ending with the
        // correct radius
        bubbles.transition()
            .duration(2000)
            .attr('r', function (d) { return d.radius; });

        // Set the simulation's nodes to our newly created nodes array.
        // @v4 Once we set the nodes, the simulation will start running automatically!
        simulation.nodes(nodes);

        // Set initial layout to single group.
        groupByLanguageArea();
    };

    /*
   * Callback function that is called after every tick of the
   * force simulation.
   * Here we do the acutal repositioning of the SVG circles
   * based on the current x and y values of their bound node data.
   * These x and y values are modified by the force simulation.
   */
    function ticked() {
        bubbles
            .attr("fill", function (d) { return fillColor(d.group) })
            .attr('stroke', function (d) { return d3.rgb(fillColor(d.group)).darker(); })
            .attr('cx', function (d) { return d.x ? d.x : 0; })
            .attr('cy', function (d) { return d.y ? d.y : 0; })
            .on('mouseover', showDetail)
            .on('mouseout', hideDetail);;
    }






    /* Zuteilung der Zentren wo sich die Bubbles hinbewegen.
   * 
   */


    function nodeLanguageAreaPos(d) {
        if (d.filter == 'Sprachgebiet') {
            return languageAreaCenters[d.subFilter].x;
        }
    }

    function nodeRegionPos(d) {
        if (d.filter == 'Region')
            return regionCenters[d.subFilter].x;
    }

    function nodePlacePurchasePos(d) {
        if (d.filter == 'Einkaufsort')  
            return placePurchaseCenters[d.subFilter].x;
    }

    function nodeIncomePos(d) {
        if (d.filter == 'Einkommen')  
            return incomeCenters[d.subFilter].x;
    }

    function nodeAgeRpPos(d) {
        if (d.filter == 'Alter Referenzperson')  
            return ageRpCenters[d.subFilter].x;
    }

    function nodeHhSizePos(d) {
        if (d.filter == 'Haushaltsgrösse')  
            return hhSizeCenters[d.subFilter].x;
    }

    function nodeNrKidsPos(d) {
        if (d.filter == 'Anzahl Kinder')  
            return nrKidsCenters[d.subFilter].x;
    }






    //Hier wird gefiltert nach Vergleichssegment, Bereich und Jahr. 

    function filterBubble(filter) {
        nodesX = [];
        for (var node of nodes) {
            if (node.filter == filter) {
                nodesX.push(node);
            } 
        }


        nodesX = filterBereich(nodesX);
        nodesX = filterYear(nodesX);


        bubbles = svg.selectAll('circle').data(nodesX);
        bubbles.exit().remove();  
        var bubblesE = bubbles.enter().append('circle')
        .classed('bubble', true)
        .attr('r', 0)
        .attr('cx', 0)
        .attr('cy', 0)
        .attr('percentage', function(d) {return d.percent})
        .attr('group', function(d) {return d.group})
        .attr('fill', function (d) { 
            return fillColor(d.group);
        })
        .attr('stroke', function (d) { return d3.rgb(fillColor(d.group)).darker(); })
        .attr('stroke-width', 2)
        .on('mouseover', showDetail)
        .on('mouseout', hideDetail);


        // @v4 Merge the original empty selection and the enter selection
        bubbles = bubbles.merge(bubblesE);

        // Fancy transition to make bubbles appear, ending with the
        // correct radius
        bubbles.transition()
            .duration(0)
            .attr('r', function (d) { return d.radius; });

        simulation.nodes(nodesX);

    }






    //filter by Bereich

    function filterBereich(nodesX) {
        var filteredNodes = [];
        d3.selectAll('.radioBtn')._groups[0].forEach(item => {
            if (item.checked) {
                for (const node of nodesX) {
                    if (node.bereich == item.value) {
                        filteredNodes.push(node);                
                    }

                }
            }
        });
        return filteredNodes;
    }


    //filter by Year

    function filterYear(nodesX) {
        var filteredNodes = [];
        d3.selectAll('.slider')._groups[0].forEach(item => { {
            for (const node of nodesX) {
                if (node.year == item.value) {
                    filteredNodes.push(node);                
                }

            }
        }
                                                           });
        return filteredNodes;
    }  







    /* Hier werden die richtigen Bubbles gefiltert und an die richtige Position gebracht. Auch werden die dazugehörigen Titel eingeblendet.(GroupBubbles werden wir nicht in unserer Visualisierung nicht brauchen)
   * Sets visualization in "single group mode".
   * The year labels are hidden and the force layout
   * tick function is set to move all nodes to the
   * center of the visualization.
   */
    function groupBubbles() {
        hideLanguageAreaTitles();
        hideRegionTitles();
        hidePlacePurchaseTitles();
        hideIncomeTitles();
        hideAgeRpTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();


        filterBubble('all')  
        
        // @v4 Reset the 'x' force to draw the bubbles to the center.
        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));

        // @v4 We can reset the alpha value and restart the simulation
        simulation.alpha(1).restart();
    }




    function groupByLanguageArea() {
        
        hideRegionTitles();
        hidePlacePurchaseTitles();
        hideIncomeTitles();
        hideAgeRpTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();
        showLanguageAreaTitles();

        filterBubble('Sprachgebiet')
        
        showPercentage(languageAreaPercentageX);
        
        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodeLanguageAreaPos));
        simulation.alpha(1).restart();   
        }, 200)


        simulation.alpha(1).restart();  
    } 
   




    function groupByRegion() {
        hideLanguageAreaTitles();
        hidePlacePurchaseTitles();
        hideIncomeTitles();
        hideAgeRpTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();
        showRegionTitles();

        filterBubble('Region')

        showPercentage(regionPercentageX);


        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodeRegionPos));
        simulation.alpha(1).restart();   
        }, 200)
    }




    function groupByPlacePurchase() {
        hideLanguageAreaTitles();
        hideRegionTitles();
        hideIncomeTitles();
        hideAgeRpTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();
        showPlacePurchaseTitles();

        filterBubble('Einkaufsort')

        showPercentage(placePurchasePercentageX);

        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodePlacePurchasePos));
        simulation.alpha(1).restart();   
        }, 200)
    }




    function groupByIncome() {
        hideLanguageAreaTitles();
        hideRegionTitles();
        hidePlacePurchaseTitles();
        hideAgeRpTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();
        showIncomeTitles();

        filterBubble('Einkommen')

        showPercentage(incomePercentageX);

        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodeIncomePos));
        simulation.alpha(1).restart();   
        }, 200)
    }




    function groupByAgeRp() {
        hideLanguageAreaTitles();
        hideRegionTitles();
        hidePlacePurchaseTitles();
        hideIncomeTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();
        showAgeRpTitles();

        filterBubble('Alter Referenzperson')

        showPercentage(ageRpPercentageX);

        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodeAgeRpPos));
        simulation.alpha(1).restart();   
        }, 200)
    }




    function groupByHhSize() {
        hideLanguageAreaTitles();
        hideRegionTitles();
        hidePlacePurchaseTitles();
        hideIncomeTitles();
        hideAgeRpTitles();
        hideHhChildrenTitles();
        hideNrKidsTitles();
        showHhSizeTitles();


        filterBubble('Haushaltsgrösse')

        showPercentage(hhSizePercentageX);

        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodeHhSizePos));
        simulation.alpha(1).restart();   
        }, 200)
    }




    function groupByNrKids() {

        hideLanguageAreaTitles();
        hideRegionTitles();
        hidePlacePurchaseTitles();
        hideIncomeTitles();
        hideAgeRpTitles();
        hideHhSizeTitles();
        hideHhChildrenTitles();
        showNrKidsTitles();

        filterBubble('Anzahl Kinder')

        showPercentage(nrKidsPercentageX);

        simulation.force('x', d3.forceX().strength(forceStrength).x(center.x));
        simulation.alpha(1).restart();
        
        setTimeout(() => {
        simulation.force('x',d3.forceX().strength(forceStrength).x(nodeNrKidsPos));
        simulation.alpha(1).restart();   
        }, 200)
    }




    /*
   * Hides titles.
   */

    function hideLanguageAreaTitles() {
        svg.selectAll('.year').remove();
    }

    function hideRegionTitles() {
        svg.selectAll('.year').remove();
    }

    function hidePlacePurchaseTitles() {
        svg.selectAll('.year').remove();
    }

    function hideIncomeTitles() {
        svg.selectAll('.year').remove();
    }

    function hideAgeRpTitles() {
        svg.selectAll('.year').remove();
    }

    function hideHhSizeTitles() {
        svg.selectAll('.year').remove();
    }

    function hideHhChildrenTitles() {
        svg.selectAll('.hhChildren').remove();
    }

    function hideNrKidsTitles() {
        svg.selectAll('.nrKids').remove();
    }








    /*
   * Shows Titles.
   */

    function showLanguageAreaTitles() {
        var languageAreaData = d3.keys(languageAreaTitleX);
        var languageArea = svg.selectAll('.year')
        .data(languageAreaData);

        languageArea.enter().append('text')
            .attr('class', function(d) {
            return 'year';
        })
            .attr('x', function (d) { 
            return languageAreaTitleX[d];
        })
            .attr('y', 40)                          
            .attr('text-anchor', 'middle')
            .text(function (d) {
            return d;

        });
    }




    function showRegionTitles() {
        var regionData = d3.keys(regionTitleX);
        var region = svg.selectAll('.year')
        .data(regionData);

        region.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return regionTitleX[d];
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }




    function showPlacePurchaseTitles() {
        var placePurchaseData = d3.keys(placePurchaseTitleX);
        var placePurchase = svg.selectAll('.year')
        .data(placePurchaseData);

        placePurchase.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return placePurchaseTitleX[d];
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }    




    function showIncomeTitles() {
        var incomeData = d3.keys(incomeTitleX);
        var income = svg.selectAll('.year')
        .data(incomeData);

        income.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return incomeTitleX[d].x;
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }




    function showAgeRpTitles() {
        var ageRpData = d3.keys(ageRpTitleX);
        var ageRp = svg.selectAll('.year')
        .data(ageRpData);

        ageRp.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return ageRpTitleX[d].x;
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }





    function showHhSizeTitles() {
        var hhSizeData = d3.keys(hhSizeTitleX);
        var hhSize = svg.selectAll('.year')
        .data(hhSizeData);

        hhSize.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return hhSizeTitleX[d].x;
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }




    function showHhChildrenTitles() {
        var hhChildrenData = d3.keys(hhChildrenTitleX);
        var hhChildren = svg.selectAll('.year')
        .data(hhChildrenData);

        hhChildren.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return hhChildrenTitleX[d].x;
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }




    function showNrKidsTitles() {
        var nrKidsData = d3.keys(nrKidsTitleX);
        var nrKids = svg.selectAll('.year')
        .data(nrKidsData);

        nrKids.enter().append('text')
            .attr('class', 'year')
            .attr('x', function (d) { 
            return nrKidsTitleX[d].x;
        })
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(function (d) { return d; });
    }


function createContext(data) {
   var bubbles = svg.selectAll('.bubble').data(data);
    console.log(data);

        // Create new circle elements each with class `bubble`.
        // There will be one circle.bubble for each object in the nodes array.
        // Initially, their radius (r attribute) will be 0.
        // @v4 Selections are immutable, so lets capture the
        //  enter selection to apply our transtition to below.
        var bubblesE = bubbles.enter().append('circle')
        .classed('percent', true)
        .attr('r', 0)
        .attr('y', function(d) {console.log(d); return d.x})
        .attr('x', function(d) {console.log(d); return d.y;});

        // @v4 Merge the original empty selection and the enter selection
        
}
// Hier werden die zu den aktiven Bubbles zugehörigen BIO-Prozentangaben geholt und eingeblendet. Dann wird ein count-up Transition der Zahl durchgeführt. 
    
    function showPercentage(titles) {
        percentage = {};
        svg.selectAll('.percentage').remove();
        for (const d of d3.keys(titles)) {
            if (d3.keys(percentage).indexOf(d.toUpperCase()) == -1) {
                var x = titles[d] && titles[d].x ? titles[d].x : titles[d];
                percentage[d.toUpperCase()] = {x: x, y: 590};
            }
        }

        var percentageData = d3.keys(percentage);
        var percentageArea = svg.selectAll('.percentage')
        .data(percentageData);
       
        var bubbles = percentageArea.enter().append('circle')
        .classed('bubble', true)
        .attr('r', 15)
        .attr('fill', '#0a8c2d')
        .attr('stroke', '#07621f')
        .attr('stroke-width', 2)
        .attr('cx', function(d) {return percentage[d].x - 70 })
        .attr('cy', function(d) { return percentage[d].y - 8});
        
         

        var text = percentageArea.enter().append('text')
        .attr('class', function(d) {
            return 'percentage';
        })
        .attr('x', function (d) { 
            var keys = d3.keys(percentageData);
            for (const node of nodesX) {
                if (keys.indexOf(node.subFilter.toUpperCase()) == -1 && percentage[node.subFilter.toUpperCase()].value == undefined && node.group == 'Bio') {
                    percentage[node.subFilter.toUpperCase()].value = node.percent;

                }
            }
            return percentage[d].x;
        })
        .attr('y', function (d) { 
            return percentage[d].y;
        })
        .attr('text-anchor', 'middle')
        .text(function (d) {
            return percentage[d].value;

        });

        text.transition().tween("text", function() {
            var end = parseFloat(d3.select(this).text(), 10)
            if (!isNaN(end)) {
                var selection = d3.select(this);    // selection of node being transitioned
                var start = 0; // start value prior to transition
                var interpolator = d3.interpolateNumber(start,end); // d3 interpolator
                return function(t) { selection.text("Bio " + Math.round((interpolator(t) + Number.EPSILON) * 10) / 10 + '%')  };  // return value
            }


        }).duration(2000);
    }







    /*
   * Function called on mouseover to display the
   * details of a bubble in the tooltip.
   */
    function showDetail(d) {
        // change outline to indicate hover state.
        d3.select(this).attr('stroke', 'black');

        var content = '<span class="name">Produkt: </span><span class="value">' +
            d.bereich +
            '</span><br/>';
        
        content += '<span class="name">Vergleichsgruppe: </span><span class="value">' + d.filter +
            '</span><br/>';
        
        content += '<span class="name">Jahr: </span><span class="value">' + d.year +
            '</span><br/>';
        
        content += '<br><span class="name"></span><span class="value">'
            '</span>';
        
        content += '<span class="name">Gesamtmenge in Einheit: </span><span class="value">' + addCommas(d.totalAmount) + " " + d.unit +
            '</span><br/>';
        
        
        if (d.group == 'Bio') {
            content +=  '<span class="name">Mengenanteil Bio: </span><span class="value">' +
                addCommas(d.amount) + " " + d.unit +
                '</span>';

        } else {
            content += '<span class="name">Mengenanteil Nicht-Bio: </span><span class="value">' +
                addCommas(d.amount) + " " +d.unit +
            '</span>';
        }
    
        if (d.group == 'Bio') {
            content +=  '<br><span class="name">Mengenanteil Bio in Prozent: </span><span class="value">' +
                addCommas(d.percent) + "%"
                '</span>';

        } else {
            content += '<br><span class="name">Mengenanteil Nicht-Bio in Prozent: </span><span class="value">' +
                addCommas(d.percent) + "%"
            '</span>';
        }
        
        content += '<br><span class="name"></span><span class="value">'
            '</span>';
        
        content += '<br><span class="name">Gesamtwert in CHF: </span><span class="value">' +
            addCommas(d.totalValue) + " CHF"
            '</span>';
        
        
        if (d.group == 'Bio') {
            content +=  '<br><span class="name">Wertanteil Bio: </span><span class="value">' +
                addCommas(d.value) + " CHF"
                '</span>';

        } else {
            content += '<br><span class="name">Wertanteil Nicht-Bio: </span><span class="value">' +
                addCommas(d.value) + " CHF"
            '</span>';
        }
        
        if (d.group == 'Bio') {
            content +=  '<br><span class="name">Wertanteil Bio in Prozent: </span><span class="value">' +
                addCommas(d.percentOfValue) + "%"
                '</span>';

        } else {
            content += '<br><span class="name">Wertanteil Nicht-Bio Prozent: </span><span class="value">' +
                addCommas(d.percentOfValue) + "%"
            '</span>';
        }

        
        

         
        



        //Tooltip

        tooltip.showTooltip(content, d3.event);
    }

    /*
   * Hides tooltip
   */
    function hideDetail(d) {
        // reset outline
        d3.select(this)
            .attr('stroke', d3.rgb(fillColor(d.group)).darker());

        tooltip.hideTooltip();
    }






    /*
   * Externally accessible function (this is attached to the
   * returned chart function). Allows the visualization to toggle
   * between Filter modes.
   to
   * displayName is expected to be a string and either 'year' or 'all'.
   */
    chart.toggleDisplay = function (buttonFilter) {
        switch(buttonFilter) {
            case 'all':
                groupBubbles();
                break;
            case 'languageArea':
                groupByLanguageArea();
                break;
            case 'region':
                groupByRegion();
                break;
            case 'placePurchase':
                groupByPlacePurchase();
                break;
            case 'income':
                groupByIncome();
                break;
            case 'ageRp':
                groupByAgeRp();
                break;
            case 'hhSize':
                groupByHhSize();
                break;
            case 'hhChildren':
                groupByHhChildren();
                break;
            case 'nrKids':
                groupByNrKids();
                break;
            default: 
                groupByLanguageArea();

        }

    };

    // return the chart function from closure.
    return chart;
}




/*
 * Below is the initialization code as well as some helper functions
 * to create a new bubble chart instance, load the data, and display it.
 */

var myBubbleChart = bubbleChart();

/*
 * Function called once data is loaded from CSV.
 * Calls bubble chart function to display inside #vis div.
 */
function display(error, data) {
    if (error) {
        console.log(error);
    }

    myBubbleChart('#vis', data);
}




// Nice looking colors - no reason to buck the trend
// @v4 scales now have a flattened naming scheme
var fillColor = d3.scaleOrdinal()
.domain(['Bio', 'Nicht Bio'])
.range(['#0a8c2d', '#3a5da8',]);




/*
 * Sets up the layout buttons to allow for toggling between view modes.
 */
function setupButtons() {
    d3.select('#toolbar')
        .selectAll('.button')
        .on('click', function () {
        // Remove active class from all buttons
        d3.event.stopImmediatePropagation();
        d3.selectAll('.button').classed('active', false);
        // Find the button just clicked
        var button = d3.select(this);

        // Set it as the active button
        button.classed('active', true);

        // Get the id of the button
        var buttonId = button.attr('id');

        // Toggle the bubble chart based on
        // the currently clicked button.
        myBubbleChart.toggleDisplay(buttonId);
    });
}




function setupRadioBtns() {
    d3.select('#radiogrp')
        .selectAll('.radioBtn')
        .on('click', function () {
        // Remove active class from all buttons
        d3.event.stopImmediatePropagation();

        // Get the id of the active button
        d3.selectAll('.button').each(function(a, index, nodeList) {
            if (nodeList[index].classList.contains('active')) {
                myBubbleChart.toggleDisplay(nodeList[index].id);
            }
        })

    }); 
}




function setupSliderRange() {
    d3.select('#myRange')
        .on('change', function () {
        // Remove active class from all buttons
        d3.event.stopImmediatePropagation();
        // Get the id of the active button
        d3.selectAll('.button').each(function(a, index, nodeList) {
            if (nodeList[index].classList.contains('active')) {
                myBubbleChart.toggleDisplay(nodeList[index].id);
            }
        })
    }); 
}

/*
 * Helper function to convert a number into a string
 * and add commas to it to improve presentation.
 */
function addCommas(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }

    return x1 + x2;
}


// setup the buttons.
setupButtons();

setupRadioBtns();

setupSliderRange();




// Load the data.
d3.csv('data/biodata.csv', display);



